#!/usr/bin/env bash
java -jar MooTool-1.0.jar